from django.apps import AppConfig


class SlugifyConfig(AppConfig):
    name = 'slugify'
