from django.shortcuts import render

def slugify(request):
    context = {}
    slug_input = request.GET.get("slug-input")
    if slug_input:
        context["slug"] = slug_input
        return render(request, 'index.html', context)
    else:
        return render(request, 'index.html', context)
